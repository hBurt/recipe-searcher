

# InlineObject9

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** | The text in which food items such as dish names and ingredients should be detected in. | 



