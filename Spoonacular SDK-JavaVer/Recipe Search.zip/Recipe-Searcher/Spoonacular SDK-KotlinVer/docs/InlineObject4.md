
# InlineObject4

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instructions** | **kotlin.String** | The instructions text. | 



