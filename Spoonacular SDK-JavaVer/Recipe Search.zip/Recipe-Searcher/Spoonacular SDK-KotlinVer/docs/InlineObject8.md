
# InlineObject8

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**locale** | **kotlin.String** | The locale of the returned category, supported is en_US and en_GB. |  [optional]



