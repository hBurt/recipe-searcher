package com.example.recipesearch.ui.meal_planner;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import com.example.recipesearch.R;


public class MealPlannerFragment extends Fragment
{
    private MealPlannerModel mealPlannerModel;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        mealPlannerModel =
                ViewModelProviders.of(this).get(MealPlannerModel.class);
        View root = inflater.inflate(R.layout.meal_planner, container, false);
        final TextView textView = root.findViewById(R.id.Recipe_Name);
        mealPlannerModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);

            }
        });
        return root;
    }


}